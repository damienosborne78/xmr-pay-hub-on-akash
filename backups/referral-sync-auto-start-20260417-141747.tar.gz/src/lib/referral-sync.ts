/**
 * Referral Telemetry Sync
 *
 * Periodically sends each user's referral data to the creator server
 * over HTTPS (port 443). Users are identified by their unique
 * wallet-derived referral code (e.g. "J84HX3").
 *
 * No sensitive data (keys, seeds) is ever transmitted.
 */

import { CREATOR_SERVER_FQDN } from './mock-data';

const SYNC_INTERVAL_MS = 60_000; // 60 seconds
const SYNC_ENDPOINT = `https://${CREATOR_SERVER_FQDN}/api/mf/referral/sync`;
const MAX_RETRY_BACKOFF_MS = 300_000; // 5 minutes max backoff

let syncTimer: ReturnType<typeof setInterval> | null = null;
let isFirstSyncDone = false;
let failedAttempts = 0;
let isOnline = true;

export interface ReferralSyncPayload {
  referralCode: string;
  proCode: string | null;
  referredBy: string | null;
  proStatus: 'free' | 'pro';
  proActivatedAt: string | null;
  referrals: Array<{
    username: string;
    level: number;
    commission: number;
    status: string;
    joinedAt: string;
  }>;
  referralPayouts: Array<{
    xmrAmount: number;
    date: string;
    from: string;
    level: number;
    status: string;
  }>;
  lastSyncAt: string;
  isFirstSync: boolean; // Backend uses this to count new signups vs returning users
}

/**
 * Collect referral telemetry from the Zustand store getter.
 */
function collectPayload(get: () => any): ReferralSyncPayload | null {
  const state = get();
  const merchant = state.merchant;

  const referralCode = merchant?.referralWalletFingerprint;
  if (!referralCode) return null; // No fingerprint yet — skip

  // Determine the pro code used (lifetime code path)
  let proCode: string | null = null;
  if (merchant.proTxid && typeof merchant.proTxid === 'string') {
    if (merchant.proTxid.startsWith('LIFETIME-CODE-')) {
      proCode = merchant.proTxid.replace('LIFETIME-CODE-', '');
    } else {
      proCode = merchant.proTxid;
    }
  }

  return {
    referralCode,
    proCode,
    referredBy: merchant.referredBy || null,
    proStatus: (merchant.proStatus === 'pro' || merchant.proStatus === 'pro_referral') ? 'pro' : 'free',
    proActivatedAt: merchant.proActivatedAt || null,
    referrals: (state.referrals || []).map((r: any) => ({
      username: r.username || r.name || '',
      level: r.level ?? 1,
      commission: r.commission ?? 0,
      status: r.status || 'active',
      joinedAt: r.joinedAt || r.createdAt || '',
    })),
    referralPayouts: (state.referralPayouts || []).map((p: any) => ({
      xmrAmount: p.xmrAmount ?? p.amount ?? 0,
      date: p.date || p.createdAt || '',
      from: p.from || '',
      level: p.level ?? 1,
      status: p.status || 'pending',
    })),
    lastSyncAt: new Date().toISOString(),
  };
}

async function doSync(get: () => any): Promise<void> {
  try {
    const payload = collectPayload(get);
    if (!payload) return;

    const syncPayload = {
      ...payload,
      isFirstSync: !isFirstSyncDone,
    };

    const response = await fetch(SYNC_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(syncPayload),
    });

    if (response.ok) {
      // Success - reset failure counter
      failedAttempts = 0;
      isOnline = true;
      
      if (!isFirstSyncDone) {
        isFirstSyncDone = true;
      }
    } else {
      // Server error - mark offline and increment failures
      isOnline = false;
      failedAttempts++;
    }
  } catch (error) {
    // Network error - mark offline and increment failures
    isOnline = false;
    failedAttempts++;
    console.error('[ReferralSync] Sync failed:', error);
  }
}

/**
 * Calculate exponential backoff based on failed attempts
 */
function getBackoffMs(): number {
  if (failedAttempts === 0) return SYNC_INTERVAL_MS;
  const backoff = Math.min(SYNC_INTERVAL_MS * Math.pow(2, failedAttempts - 1), MAX_RETRY_BACKOFF_MS);
  return backoff;
}

/**
 * Schedule the next sync with backoff
 */
function scheduleNextSync(get: () => any): void {
  const delay = failedAttempts === 0 ? SYNC_INTERVAL_MS : getBackoffMs();
  
  syncTimer = setTimeout(() => {
    doSync(get).then(() => {
      scheduleNextSync(get); // Schedule next after this one completes
    });
  }, delay);
}

/**
 * Start the periodic referral sync. Call once after login.
 * @param get - Zustand store getter
 */
export function startReferralSync(get: () => any): void {
  stopReferralSync(); // Clear any existing timer
  
  // Immediate first sync
  doSync(get);
  
  // Start the recursive sync schedule
  scheduleNextSync(get);
  
  // Restart sync when user returns to tab/window (privacy-preserving reactivation)
  if (typeof window !== 'undefined') {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        // User is back - attempt immediate sync
        doSync(get);
      }
    };
    
    window.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Cleanup listener on stop
    (startReferralSync as any)._listener = handleVisibilityChange;
  }
}

/**
 * Stop the periodic sync. Call on logout / account deletion.
 */
export function stopReferralSync(): void {
  if (syncTimer !== null) {
    clearInterval(syncTimer);
    syncTimer = null;
  }
  isFirstSyncDone = false;
}
