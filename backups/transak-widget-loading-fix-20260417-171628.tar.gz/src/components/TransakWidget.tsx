/**
 * Transak Fiat On-Ramp Widget
 * 
 * Allows users to buy XMR directly from MoneroFlow via Transak.
 * Handles KYC, fiat payment, and XMR delivery to user's wallet.
 * 
 * Integration approach:
 * - Opens modal widget from dashboard
 * - KYC handled by Transak (compliant, licensed)
 * - XMR sent directly to user's wallet address
 * - Zero wallet custody by MoneroFlow
 */

import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { useStore } from '@/lib/store';
import { Wallet } from 'lucide-react';

declare global {
  interface Window {
    transak: any;
  }
}

export default function TransakWidget() {
  const merchant = useStore(s => s.merchant);
  const [isWidgetLoaded, setIsWidgetLoaded] = useState(false);

  const walletAddress = merchant.viewOnlyAddress;

  // Load Transak script on mount
  useEffect(() => {
    if (typeof window === 'undefined' || isWidgetLoaded) return;

    const script = document.createElement('script');
    script.src = 'https://global.transak.com/sdk/v1.1/web.js';
    script.async = true;
    
    script.onload = () => {
      console.log('[Transak] SDK loaded successfully');
      setIsWidgetLoaded(true);
    };
    
    script.onerror = () => {
      console.error('[Transak] Failed to load SDK');
    };
    
    document.body.appendChild(script);

    return () => {
      if (script.parentNode) {
        script.parentNode.removeChild(script);
      }
    };
  }, [isWidgetLoaded]);

  const openWidget = useCallback(() => {
    if (!walletAddress) {
      alert('Please complete wallet setup first');
      return;
    }

    if (!window.transak) {
      alert('On-ramp widget not yet loaded. Please wait a moment and try again.');
      return;
    }

    try {
      console.log('[Transak] Opening widget for:', walletAddress);

      const transak = new window.transak.Transak({
        apiKey: process.env.VITE_TRANSAK_API_KEY || 'DEMO_API_KEY',
        environment: process.env.VITE_TRANSAK_ENV || 'STAGING',
        defaultCrypto: 'XMR',
        fiatCurrency: 'AUD',
        walletAddress: walletAddress,
        networks: 'monero',
        themeColor: '#F97316',
        showTransactionButton: true,
        supportedFiatCurrencies: ['AUD', 'USD', 'EUR'],
        cryptoCurrencyList: ['XMR'],
        country: 'AU',
        email: merchant.notificationSettings?.email || '',
        firstName: merchant.businessName || '',
        redirectURL: window.location.origin + '/dashboard',
      });

      transak.init();

      // Event listeners
      transak.on(window.transak.EVENTS.TRANSAK_WIDGET_CLOSE, () => {
        console.log('[Transak] Widget closed');
      });

      transak.on(window.transak.EVENTS.TRANSAK_WIDGET_SUCCESS, (orderData: any) => {
        console.log('[Transak] Payment successful:', orderData);
        alert(`XMR purchased! ${orderData.cryptoAmount} XMR will arrive shortly.`);
      });

      transak.on(window.transak.EVENTS.TRANSAK_WIDGET_FAILURE, (orderData: any) => {
        console.error('[Transak] Payment failed:', orderData);
        alert(`Payment failed: ${orderData.message || 'Unknown error'}`);
      });

    } catch (error) {
      console.error('[Transak] Error opening widget:', error);
      alert('Failed to open on-ramp widget. Please refresh and try again.');
    }
  }, [walletAddress, merchant]);

  return (
    <Button
      onClick={openWidget}
      disabled={!walletAddress || !isWidgetLoaded}
      className="bg-gradient-orange hover:opacity-90 glow-orange-sm text-base px-4 h-9"
    >
      <Wallet className="w-4 h-4 mr-2" />
      Buy XMR
    </Button>
  );
}
