/**
 * Transak Fiat On-Ramp Widget
 * 
 * Allows users to buy XMR directly from MoneroFlow via Transak.
 * Handles KYC, fiat payment, and XMR delivery to user's wallet.
 * 
 * Integration approach:
 * - Opens modal widget from dashboard
 * - KYC handled by Transak (compliant, licensed)
 * - XMR sent directly to user's wallet address
 * - Zero wallet custody by MoneroFlow
 */

import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { useStore } from '@/lib/store';
import { Wallet } from 'lucide-react';

declare global {
  interface Window {
    transak: any;
  }
}

export default function TransakWidget() {
  const merchant = useStore(s => s.merchant);
  const [isOpen, setIsOpen] = useState(false);
  const [isWidgetLoaded, setIsWidgetLoaded] = useState(false);

  const walletAddress = merchant.viewOnlyAddress;

  // Initialize Transak widget on mount
  const initWidget = useCallback(() => {
    if (isWidgetLoaded || typeof window === 'undefined') return;

    // Load Transak script dynamically
    const script = document.createElement('script');
    script.src = 'https://global.transak.com/sdk/v1.1/web.js';
    script.async = true;
    script.onload = () => {
      setIsWidgetLoaded(true);
      console.log('[Transak] Widget loaded');
    };
    script.onerror = () => {
      console.error('[Transak] Failed to load widget');
    };
    document.body.appendChild(script);

    return () => {
      // Clean up on unmount
      if (script.parentElement) {
        script.parentElement.removeChild(script);
      }
    };
  }, [isWidgetLoaded]);

  // Initialize on component mount
  useState(initWidget());

  const openWidget = useCallback(() => {
    if (!walletAddress) {
      alert('Please complete wallet setup first');
      return;
    }

    if (!window.transak) {
      alert('On-ramp widget loading, please try again in a moment');
      return;
    }

    console.log('[Transak] Opening widget for:', walletAddress);

    const transak = new window.transak.Transak({
      apiKey: process.env.VITE_TRANSAK_API_KEY || 'DEMO_API_KEY',
      environment: process.env.VITE_TRANSAK_ENV || 'STAGING', // STAGING for testing, PRODUCTION for live
      defaultCrypto: 'XMR',
      fiatCurrency: 'AUD', // Australian Dollar
      walletAddress: walletAddress,
      networks: 'monero',
      hideMenu: false,
      themeColor: '#F97316', // Match branding orange
      kryllTheme: null,
      showTransactionButton: true,
      supportedFiatCurrencies: ['AUD', 'USD', 'EUR'],
      cryptoCurrencyList: ['XMR'],
      country: 'AU', // Australia default
      email: merchant.notificationSettings?.email || '',
      firstName: merchant.businessName || '',
      lastName: '',
      partnerOrderId: '', // Optional: track order in your system
      redirectURL: window.location.origin + '/dashboard',
    });

    transak.init();

    // Listen for events
    transak.on(transak.EVENTS.TRANSAK_WIDGET_CLOSE, () => {
      console.log('[Transak] Widget closed');
      setIsOpen(false);
    });

    transak.on(transak.EVENTS.TRANSAK_WIDGET_SUCCESS, (orderData: any) => {
      console.log('[Transak] Payment successful:', orderData);
      setIsOpen(false);
      
      // Show success notification (could use Toast here)
      alert(`XMR purchased successfully! ${orderData.cryptoAmount} XMR will arrive shortly.`);
      
      // Refresh wallet balance could be triggered here
    });

    transak.on(transak.EVENTS.TRANSAK_WIDGET_FAILURE, (orderData: any) => {
      console.error('[Transak] Payment failed:', orderData);
      setIsOpen(false);
      alert(`Payment failed: ${orderData.message || 'Unknown error'}`);
    });

    setIsOpen(true);
  }, [walletAddress, merchant]);

  return (
    <Button
      onClick={openWidget}
      disabled={!walletAddress}
      className="bg-gradient-orange hover:opacity-90 glow-orange-sm text-base px-4 h-9"
    >
      <Wallet className="w-4 h-4 mr-2" />
      Buy XMR
    </Button>
  );
}
